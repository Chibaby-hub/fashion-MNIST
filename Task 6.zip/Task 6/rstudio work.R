

# Load the reticulate package to interface with Python
library(reticulate)

# Set up Python environment for TensorFlow and Keras
use_virtualenv("r-tensorflow")

# Load keras library
library(keras)
library(ggplot2)

# Load and preprocess the dataset
fashion_mnist <- dataset_fashion_mnist()
train_images <- fashion_mnist$train$x
train_labels <- fashion_mnist$train$y
test_images <- fashion_mnist$test$x
test_labels <- fashion_mnist$test$y

# Normalize the images
train_images <- array_reshape(train_images, c(60000, 28, 28, 1)) / 255
test_images <- array_reshape(test_images, c(10000, 28, 28, 1)) / 255

# One-hot encode the labels
train_labels <- to_categorical(train_labels, 10)
test_labels <- to_categorical(test_labels, 10)

# Define the CNN model
model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', input_shape = c(28, 28, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 10, activation = 'softmax')

# Compile the model
model %>% compile(
  optimizer = 'adam',
  loss = 'categorical_crossentropy',
  metrics = c('accuracy')
)

# Train the model
model %>% fit(
  train_images, train_labels,
  epochs = 10, batch_size = 64, validation_split = 0.2
)

# Evaluate the model
score <- model %>% evaluate(test_images, test_labels)
cat('Test accuracy:', score$acc, "\n")

# Make predictions on two images
predictions <- model %>% predict(test_images[1:2,,,drop=FALSE])

# Display the images and predictions
par(mfrow = c(1, 2))
for (i in 1:2) {
  image(as.matrix(test_images[i,,,1]), col = gray.colors(256), main = paste("Predicted:", which.max(predictions[i, ]) - 1))
}



